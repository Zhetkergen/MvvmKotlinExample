package com.example.mvvm_kotlin_example.ui.menu

import android.view.View
import com.example.mvvm_kotlin_example.ui.BaseViewModel


class MenuViewModel(val onClickListener: View.OnClickListener) : BaseViewModel() {

}